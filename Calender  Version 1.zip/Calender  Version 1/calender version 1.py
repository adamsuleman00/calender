def main ():
    print ("Select Read (r), Append (a), or Write(w)")
    choice = raw_input()
    if choice == "r":
        f= open("testfile.txt","r")
        contents =f.read()
        print (contents)
        f.close()
    if  choice == "a":
        f= open("testfile.txt","r")
        contents =f.read()
        print (contents)
        f.close()
        f= open("testfile.txt","a")
        print ("What do you want to add to the file?")
        append = raw_input()
        appendfile = f.write(" " + str(append))
        f.close()
    if choice == "w":
        f= open("testfile.txt","w+")
        contents =f.read()
        print (contents)
        print ("What do you want to add to the file?")
        write = raw_input()
        writefile = f.write(" " + str(write))
        f.close()

def restart_main():
    print ("Would you like to restart(y/n)")
    restart = raw_input()
    if restart == "y":
        main()
        restart_main()
    else:
        raise SystemExit
main ()
restart_main()
